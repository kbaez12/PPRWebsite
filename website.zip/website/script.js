const slides       = document.querySelector('.slides');
const slide        = document.querySelectorAll('.slide');
const prev         = document.querySelector('.prev');
const next         = document.querySelector('.next');

let currentIndex   = 0;

// Show the next set of slides
next.addEventListener('click', () => {
  if (currentIndex < slide.length - 3) { 
    currentIndex++;
    slides.style.transform = `translateX(-${currentIndex * (100 / 3)}%)`;
  }
});

// Show the previous set of slides
prev.addEventListener('click', () => {
  if (currentIndex > 0) {
    currentIndex--;
    slides.style.transform = `translateX(-${currentIndex * (100 / 2)}%)`;
  }
});

window.addEventListener("scroll", () => {
  // Grab the hero image
  const heroImage = document.querySelector(".hero-image");
  if (!heroImage) return; // safety check

  // You could make the blur relative to how far down you’ve scrolled
  const scrollY = window.scrollY;
  // Cap the blur so it doesn't go too high
  const blurValue = Math.min(scrollY / 50, 8); // e.g. max blur 8px
  heroImage.style.filter = `blur(${blurValue}px)`;
});

/********************************
  3) Modal: Open when carousel images are clicked
********************************/
const modal = document.getElementById("imageModal");
const modalClose = document.getElementById("modalClose");

// Attach click event to each carousel image
document.querySelectorAll(".slide img").forEach(img => {
  img.addEventListener("click", () => {
    openModal();
  });
});

// Open modal function
function openModal() {
  modal.style.display = "block";
}

// Close modal function
function closeModal() {
  modal.style.display = "none";
}

// When user clicks on “X” (span), close modal
modalClose.addEventListener("click", closeModal);

// OPTIONAL: Close the modal if user clicks outside the modal-content
window.addEventListener("click", (event) => {
  if (event.target === modal) {
    closeModal();
  }
});